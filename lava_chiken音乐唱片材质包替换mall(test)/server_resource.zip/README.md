# Mall唱片材质包

这是一个用于Minecraft 1.21.x的材质包，用于替换原版的mall唱片。

## 功能
- 替换原版mall唱片的材质
- 替换原版mall唱片的音频为"Hyper Potions - Lava Chicken"

## 安装方法
1. 将整个文件夹复制到Minecraft的材质包目录：
   - Windows: `%appdata%\.minecraft\resourcepacks\`
   - macOS: `~/Library/Application Support/minecraft/resourcepacks/`
   - Linux: `~/.minecraft/resourcepacks/`

2. 在Minecraft中启用材质包：
   - 打开Minecraft
   - 进入"选项" → "资源包"
   - 将"mall唱片材质包"移动到右侧的"已选资源包"列表中

## 文件结构
```
mall唱片材质包/
├── pack.mcmeta                    # 材质包元数据
├── assets/
│   └── minecraft/
│       ├── textures/
│       │   └── item/
│       │       └── music_disc_mall.png    # 唱片材质
│       ├── sounds/
│       │   ├── sounds.json               # 声音定义
│       │   └── records/
│       │       └── mall.ogg              # 音频文件
│       ├── models/
│       │   └── item/
│       │       └── music_disc_mall.json  # 物品模型
│       └── lang/
│           ├── zh_cn.json                # 中文语言
│           └── en_us.json                # 英文语言
└── README.md
```

## 兼容性
- Minecraft版本: 1.21.x
- 材质包格式: 15

## 注意事项
- 此材质包仅替换mall唱片，不影响其他游戏内容
- 确保音频文件格式为.ogg
- 材质图片应为16x16像素的PNG格式
- 新的音频为"Hyper Potions - Lava Chicken" 